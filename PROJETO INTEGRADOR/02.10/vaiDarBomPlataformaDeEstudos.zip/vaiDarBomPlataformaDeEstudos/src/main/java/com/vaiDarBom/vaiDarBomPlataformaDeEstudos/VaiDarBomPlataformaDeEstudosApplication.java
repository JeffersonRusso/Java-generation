package com.vaiDarBom.vaiDarBomPlataformaDeEstudos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VaiDarBomPlataformaDeEstudosApplication {

	public static void main(String[] args) {
		SpringApplication.run(VaiDarBomPlataformaDeEstudosApplication.class, args);
	}

}
